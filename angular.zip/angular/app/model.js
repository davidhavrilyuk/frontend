var model = {
    bookmarks:[
        {id: 1, name: "google", url: "google.com", desc : "search"},
        {id: 2, name: "yahoo", url: "yahoo.com", desc : "post"},
        {id: 3, name: "youtube", url: "youtube.com", desc : "video"}
    ]
};