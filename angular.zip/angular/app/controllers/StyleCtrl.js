bookmarksApp.controller("StyleCtrl", function ($scope, $http) {
    $scope.hoverIn = function() {
        this.hover = true;
    };

    $scope.hoverOut = function() {
        this.hover = false;
    };

    $scope.hovIn = function() {
        this.cls = true;
    };

    $scope.hovOut = function() {
        this.cls = false;
    };
    $scope.list = model;
});